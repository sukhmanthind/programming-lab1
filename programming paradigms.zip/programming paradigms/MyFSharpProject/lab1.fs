using System;

class Program
{
    static Func<int, int, int> Power = (exponent, value) => (int)Math.Pow(value, exponent);

    static void Main()
    {
        // Apply partial application for square (2) and cube (3)
        Func<int, int> square = Power(2, 0);
        Func<int, int> cube = Power(3, 0);

        // Invoke square and cube with some values
        Console.WriteLine("Square of 4: " + square(4)); // 4^2 = 16
        Console.WriteLine("Cube of 2: " + cube(2)); // 2^3 = 8
    }
}
